import React from 'react';
import ProposalContent from '../components/proposal/ProposalContent_NVNG';

export default function ProposalPDF() {
  return (
    <ProposalContent />
  );
}
import React from 'react';
import PrepSheetContent from '../components/investor/PrepSheetContent';

export default function InvestorPrepSheet() {
  return (
    <PrepSheetContent />
  );
}
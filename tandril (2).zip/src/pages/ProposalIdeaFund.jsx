import React from 'react';
import ProposalContent from '../components/proposal/ProposalContent_IdeaFund';

export default function ProposalIdeaFund() {
  return <ProposalContent />;
}
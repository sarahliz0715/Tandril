import React from 'react';
import ProposalContent from '../components/proposal/ProposalContent';

export default function InvestmentProposal() {
  return (
    <ProposalContent />
  );
}
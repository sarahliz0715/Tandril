import React from 'react';
import ProposalContent from '../components/proposal/ProposalContent_gener8tor';

export default function ProposalGener8tor() {
  return <ProposalContent />;
}
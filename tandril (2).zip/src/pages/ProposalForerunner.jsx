import React from 'react';
import ProposalContent from '../components/proposal/ProposalForerunnerContent';

export default function ProposalForerunner() {
  return <ProposalContent />;
}
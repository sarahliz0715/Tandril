import React from 'react';
import ProposalContent from '../components/proposal/ProposalContent_WEDC';

export default function ProposalWEDC() {
  return <ProposalContent />;
}